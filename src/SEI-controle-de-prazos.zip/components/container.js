class Container{
    root
    constructor(id){
        this.root = document.createElement("div")
        this.root.id = "div" + id
    }
}